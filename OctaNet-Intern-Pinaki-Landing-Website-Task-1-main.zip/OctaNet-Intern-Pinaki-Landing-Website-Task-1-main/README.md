# OctaNet-Intern-Pinaki-Landing-Website-Task-1


https://github.com/PINAKIMATHAN/OctaNet-Intern-Pinaki-Landing-Website-Task-1/assets/107812574/7c6c4d5c-8456-4cb7-898f-2a095060a082

